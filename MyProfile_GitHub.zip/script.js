// Change the profile description.
const changeTextButton = document.querySelector("#changeTextButton");
const profileDescription = document.querySelector("#profileDescription");

changeTextButton.addEventListener("click", function () {
    profileDescription.textContent =
        "My goal is to develop my engineering and programming skills and learn how technology can solve real problems in healthcare.";
});

// Switch between the light and dark themes.
const changeThemeButton = document.querySelector("#changeThemeButton");

changeThemeButton.addEventListener("click", function () {
    document.body.classList.toggle("dark-theme");
});

// Display the current year in the footer.
document.querySelector("#currentYear").textContent = new Date().getFullYear();
