# My Profile — Responsive Website

A simple responsive profile website created for Assignment 5 using HTML, CSS, and JavaScript.

## Features
- Profile header, illustration, and description
- Hobbies and skills displayed in cards
- **Change Text** button using `querySelector()`, `textContent`, and `addEventListener()`
- **Change Theme** button using `classList.toggle()`
- Responsive layout: one card column below 768px and three columns from 768px
- Viewport meta tag and relative container width
- No CSS framework used

## Files
- `index.html` — page structure
- `style.css` — design and responsive layout
- `script.js` — interactive buttons

## Run locally
Open `index.html` in a browser, or use the Live Server extension in Visual Studio Code.

## Publish with GitHub Pages
1. Create a new repository on GitHub.
2. Upload these four files to the repository's root folder.
3. Open **Settings → Pages**.
4. Under the build/deployment section, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. The website URL will appear in the Pages section.

Personalize the name and profile description before submitting if needed.
